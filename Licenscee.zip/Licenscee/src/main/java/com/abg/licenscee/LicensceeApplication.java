package com.abg.licenscee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicensceeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicensceeApplication.class, args);
	}

}
