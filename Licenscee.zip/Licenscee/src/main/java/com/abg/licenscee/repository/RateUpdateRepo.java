package com.abg.licenscee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abg.licenscee.model.rateUpdate;

@Repository
public interface RateUpdateRepo extends JpaRepository<rateUpdate, Integer> {

}
