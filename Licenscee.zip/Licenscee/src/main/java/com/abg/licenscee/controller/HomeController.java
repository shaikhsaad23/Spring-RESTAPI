package com.abg.licenscee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abg.licenscee.model.rateUpdate;
import com.abg.licenscee.repository.RateUpdateRepo;

@RestController
@RequestMapping("/")
public class HomeController {
	
	@Autowired
	private RateUpdateRepo repo;
	
	@RequestMapping("/")
	public String serviceStarted() {
		return "0000";
	}

	@GetMapping("getRates/")
	public List<rateUpdate> getRates() {

		return repo.findAll();
	}

	@PutMapping("updateRate/")
	public rateUpdate updateRates(@RequestBody rateUpdate updateRates) {

		return repo.save(updateRates);
	}

}
