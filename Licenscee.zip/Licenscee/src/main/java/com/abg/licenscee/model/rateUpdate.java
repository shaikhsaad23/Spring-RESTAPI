package com.abg.licenscee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="rate_update")
public class rateUpdate {
	@Id
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="email")
	private String email;
	
//	@Column(name="mobile")
//	private int mobile;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	public int getMobile() {
//		return mobile;
//	}
//
//	public void setMobile(int mobile) {
//		this.mobile = mobile;
//	}

	@Override
	public String toString() {
		return "rateUpdate [id=" + id + ", name=" + name + ", email=" + email  + "]";
	}
	
}
